package sk.tuke.oop.game;

import sk.tuke.oop.framework.SlickWorld;
import sk.tuke.oop.game.actors.Alien;
import sk.tuke.oop.game.actors.Ripley;

public class Main {

    /**
     * The application's entry point.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // your `code goes here
        System.out.println("Greetings from Manager");
        // Argumenty sa daju zistit ctrl click
        SlickWorld w = new SlickWorld("World",800,600);
        // uloha 2.6
        w.addActor(new Ripley());
        // Uloha 4.4
        w.addActor(new Alien());
        w.run();
    }
}

package sk.tuke.oop.game.actors;


import sk.tuke.oop.framework.*;

public class Ripley implements Movable {
    private int x;
    private int y;
    private int width;
    private int height;
    private String name;
    private Animation animation;
    Move move;


    public Ripley() {
        move = new Move();
        name = "Ripley";
        x = 100;
        y = 100;
        width = 32;
        height = 32;
        animation = new Animation("sprites/player.png",width,height,100);

    }


    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    @Override
    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public Animation getAnimation() {
        return animation;
    }

    @Override
    public void setAnimation(Animation animation) {
        this.animation = animation;

    }

    @Override
    public void act() {

        Input input = Input.getInstance();
        if(input.isKeyDown(Input.Key.ESCAPE)){
            System.exit(0);
        }
        // Uloha 3.1
//        if (input.isKeyDown(Input.Key.UP)){
//            step(2,0,-1);
//        }
//        if (input.isKeyDown(Input.Key.DOWN)){
//            step(2,0,1);
//        }
//        if (input.isKeyDown(Input.Key.LEFT)){
//            step(2,-1,0);
//        }
//        if (input.isKeyDown(Input.Key.RIGHT)){
//            step(2,1,0);
//        }

        if (input.isKeyDown(Input.Key.UP)){
            move.execute(this,2,0,-1);
        }
        if (input.isKeyDown(Input.Key.DOWN)){
            move.execute(this,2,0,1);
        }
        if (input.isKeyDown(Input.Key.LEFT)){
            move.execute(this,2,-1,0);
        }
        if (input.isKeyDown(Input.Key.RIGHT)){
            move.execute(this,2,1,0);
        }
    }

//    private void step(int step, int dx,int dy){
//        x += step * dx;
//        y += step * dy;
//    }


    @Override
    public boolean intersects(Actor actor) {
        return false;
    }

    @Override
    public void addedToWorld(World world) {

    }

    @Override
    public World getWorld() {
        return null;
    }

    @Override
    public String getName() {

        return name;
    }
}

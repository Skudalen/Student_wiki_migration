package sk.tuke.oop.game.actors;

public class Move  {
    public void execute(Movable actor, int step, int dx, int dy){
        actor.setPosition(actor.getX() + step * dx, actor.getY() + step * dy);
        int angle = 0;
        // Tuto treba domysliet ako sa pocita uhol podla dx, dy, sorry nestiham
        angle = (int)Math.round(Math.toDegrees((double)dx / (double)dy * Math.PI));
        actor.getAnimation().setRotation(angle);

    }

}

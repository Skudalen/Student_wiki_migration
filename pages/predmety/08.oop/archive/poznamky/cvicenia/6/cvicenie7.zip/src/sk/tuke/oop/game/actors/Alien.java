package sk.tuke.oop.game.actors;

import sk.tuke.oop.framework.Actor;
import sk.tuke.oop.framework.Animation;
import sk.tuke.oop.framework.World;

import java.util.Random;

public class Alien implements Movable {
    private int x;
    private int y;
    private int width;
    private int height;
    private String name;
    private Animation animation;
    Move move = new Move();


    int round;
    int dx;
    int dy;
    Random rnd;



    public Alien() {
        name = "alien";
        x = 200;
        y = 100;
        width = 32;
        height = 32;
        rnd = new Random();
        animation = new Animation("sprites/warrior_alien.png",width,height,100);
    }


    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    @Override
    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public Animation getAnimation() {

        return animation;
    }

    @Override
    public void setAnimation(Animation animation) {
        this.animation = animation;

    }


    @Override
    public void act() {

        round += 1;
        if (round % 100 == 99) {
            dx = rnd.nextInt(2) - 1;
            dy = rnd.nextInt(2) - 1;
        }
        move.execute(this,2,dx,dy);
        //step(2,dx,dy);

    }

//    private void step(int step, int dx,int dy){
//        x += step * dx;
//        y += step * dy;
//    }


    @Override
    public boolean intersects(Actor actor) {
        return false;
    }

    @Override
    public void addedToWorld(World world) {

    }

    @Override
    public World getWorld() {
        return null;
    }

    @Override
    public String getName() {

        return name;
    }
}

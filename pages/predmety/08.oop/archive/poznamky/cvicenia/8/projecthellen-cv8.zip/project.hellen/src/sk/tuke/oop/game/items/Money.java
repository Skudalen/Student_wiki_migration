package sk.tuke.oop.game.items;

import sk.tuke.oop.framework.Item;
import sk.tuke.oop.game.actors.AbstractActor;

public class Money extends AbstractActor implements Item {
    public Money(){
        super("Money","resources/sprites/money.png",16,16);
    }
    @Override
    public void act() {

    }
}
package sk.tuke.oop.game.actions;

import sk.tuke.oop.framework.*;

public interface Movable extends Actor {
}

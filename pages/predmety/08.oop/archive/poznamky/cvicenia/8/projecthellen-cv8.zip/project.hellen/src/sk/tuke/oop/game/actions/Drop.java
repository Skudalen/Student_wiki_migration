package sk.tuke.oop.game.actions;

import sk.tuke.oop.framework.Actor;
import sk.tuke.oop.framework.ActorContainer;
import sk.tuke.oop.framework.World;

public class Drop<A extends Actor> implements Action {
    ActorContainer<A> container;
    World world;
    int x;
    int y;
    public Drop(ActorContainer<A> container, World world, int x, int y){
        this.container = container;
        this.world = world;
        this.x = x;
        this.y = y;
    }

    @Override
    public void execute() {
        try {
            Actor a = container.peek();
            container.remove((A) a);
            a.setPosition(x, y);
            world.addActor(a);
        }
        catch (ArrayIndexOutOfBoundsException ex){
            ex.printStackTrace();
            // A vypisat spravu na obrazovku?
        }

    }
}

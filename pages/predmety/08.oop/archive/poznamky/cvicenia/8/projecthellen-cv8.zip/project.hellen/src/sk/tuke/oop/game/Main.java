package sk.tuke.oop.game;

import sk.tuke.oop.framework.SlickWorld;
import sk.tuke.oop.game.actors.Alien;
import sk.tuke.oop.game.actors.Body;
import sk.tuke.oop.game.actors.Ripley;
import sk.tuke.oop.game.actors.Ventilator;
import sk.tuke.oop.game.items.Ammo;
import sk.tuke.oop.game.items.Energy;

public class Main {

    /**
     * The application's entry point.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SlickWorld w = new SlickWorld("World",800,600);
        w.addActor(new Ripley());
        w.addActor(new Alien());
        w.addActor(new Ammo());
        w.addActor(new Energy());
        w.addActor(new Ventilator());
        w.addActor(new Body());
        w.run();

    }
}

package sk.tuke.oop.game.items;

import sk.tuke.oop.framework.Actor;
import sk.tuke.oop.framework.Item;
import sk.tuke.oop.game.actors.AbstractActor;
import sk.tuke.oop.game.actors.Ripley;

public class Ammo extends AbstractActor implements Item {
    public Ammo() {
        super("ammo", "sprites/ammo.png", 16, 16);
    }

    @Override
    public void act() {
        for (Actor actor : getWorld()) {
            if (actor.getName() == Ripley.NAME && actor.intersects(this)){
                Ripley r = (Ripley)actor;
                int ra = r.getAmmo();
                if (ra < Ripley.FULLAMMO){
                    r.setAmmo(ra + 50);
                    if (r.getAmmo() >= Ripley.FULLAMMO) {
                        r.setAmmo(Ripley.FULLAMMO);
                    }
                    getWorld().removeActor(this);
                }

            }
            System.out.println(actor);
        }
    }
}

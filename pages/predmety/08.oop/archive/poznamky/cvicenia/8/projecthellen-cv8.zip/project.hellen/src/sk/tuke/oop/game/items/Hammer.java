package sk.tuke.oop.game.items;

import sk.tuke.oop.framework.Item;
import sk.tuke.oop.game.actors.AbstractActor;

public class Hammer extends AbstractActor implements Item {
    public Hammer(){
        super("Hammer","resources/sprites/hammer.png",16,16);
    }
    @Override
    public void act() {

    }
}

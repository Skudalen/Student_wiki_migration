package sk.tuke.oop.game.actions;


public class Move implements Action {
    private final Movable actor;
    private final int step;
    private final int dx;
    private final int dy;
    public Move(Movable actor, int step, int dx, int dy){
        this.actor = actor;
        this.step = step;
        this.dy = dy;
        this.dx = dx;
    }
    public void execute(){
        actor.setPosition(actor.getX() + step * dx, actor.getY() + step * dy);
        int angle = 0;
        // Tuto treba domysliet ako sa pocita uhol podla dx, dy, sorry nestiham
        angle = (int)Math.round(Math.toDegrees((double)dx / (double)dy * Math.PI));
        actor.getAnimation().setRotation(angle);
    }

}

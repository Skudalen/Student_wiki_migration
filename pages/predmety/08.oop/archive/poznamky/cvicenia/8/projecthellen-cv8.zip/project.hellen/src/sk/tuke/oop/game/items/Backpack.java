package sk.tuke.oop.game.items;

import sk.tuke.oop.framework.ActorContainer;
import sk.tuke.oop.framework.Item;

import java.util.*;

public class Backpack implements ActorContainer<Item>{
    private List<Item> items = new ArrayList<>();
    private int capacity;
    public Backpack(int capacity){
        this.capacity = capacity;
    }
    @Override
    public void add(Item actor) {
        if (items.size() == capacity)
            throw new ArrayIndexOutOfBoundsException();
        items.add(actor);

    }

    @Override
    public void remove(Item actor) {
        if(!items.remove(actor)){
            throw  new NoSuchElementException();
        }
    }

    @Override
    public Item peek() {
        // Toto moze zlyhat ak nie je v items dost prvkov.
        return items.get(items.size() -1);

    }

    @Override
    public List<Item> getContent() {
        return new ArrayList<>(items);
    }

    @Override
    public void shiftContent() {
        Collections.rotate(items,1);
    }

    @Override
    public int getCapacity() {
        return capacity;
    }

    @Override
    public String getName() {
        return "backpack";
    }

    @Override
    public Iterator<Item> iterator() {
        return items.iterator();
    }
}

package sk.tuke.oop.game.actors;


import sk.tuke.oop.framework.*;
import sk.tuke.oop.game.actions.*;
import sk.tuke.oop.game.items.Backpack;

import java.util.ArrayList;
import java.util.List;

public class Ripley extends AbstractActor {

    private int health;
    private int ammo;
    public static final String NAME = "Ripley";
    public static final int FULLENERGY = 100;
    public static final int FULLAMMO = 500;

    private Backpack backpack;

    public Ripley() {
        super(NAME,"sprites/player.png",32,32);
        setHealth(FULLENERGY);
        setAmmo(FULLAMMO);
        backpack = new Backpack(10);
    }


    @Override
    public void act() {
        Input input = Input.getInstance();
        if (input.isKeyDown(Input.Key.ESCAPE)) {
            System.exit(0);
        }
        List<Action> al = new ArrayList<Action>();
        if (input.isKeyDown(Input.Key.UP)) {
            al.add(new Move(this, 2, 0, -1));
        }
        if (input.isKeyDown(Input.Key.DOWN)) {
            al.add(new Move(this, 2, 0, 1));
        }
        if (input.isKeyDown(Input.Key.LEFT)) {
            al.add(new Move(this, 2, -1, 0));
        }
        if (input.isKeyDown(Input.Key.RIGHT)) {
            al.add( new Move(this, 2, 1, 0));
        }


        for (Actor actor : getWorld()) {
            if (actor.intersects(this)){
                if (input.isKeyDown(Input.Key.E)){
                    // Pozor - tu moze nastat ClassCast Exception
                    // Ako zistime, ci Actor implementuje Usable ???
                    al.add(new Use(this,(Usable) actor));
                }
                if (input.isKeyDown(Input.Key.ENTER)){
                    al.add(new Take(backpack,actor));
                }
            }
        }
        if (input.isKeyDown(Input.Key.BACK)){
            al.add(new Drop(backpack,getWorld(),getX(),getY()));
        }
        if (input.isKeyDown(Input.Key.BACK)){
            al.add(new Shift(backpack));
        }
        for (Action a : al){
            a.execute();
        }

    }

    @Override
    public void addedToWorld(World world) {
        // Rozšírime funkčnosť metódy z predka
        super.addedToWorld(world);
        world.showActorContainer(backpack);
    }


    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getAmmo() {
        return ammo;
    }

    public void setAmmo(int ammo) {
        this.ammo = ammo;
    }
}

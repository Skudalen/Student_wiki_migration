package sk.tuke.oop.game.actors;

import sk.tuke.oop.framework.Actor;
import sk.tuke.oop.framework.Item;
import sk.tuke.oop.game.items.Backpack;
import sk.tuke.oop.game.items.Hammer;
import sk.tuke.oop.game.items.Money;
import sk.tuke.oop.game.items.Wrench;

public class Body extends AbstractActor implements Usable  {
    private Backpack backpack;
    public Body(){
        super("body","resources/sprites/body.png",64,48);
        setPosition(232,345);
        backpack = new Backpack(3);
        backpack.add(new Hammer());
        backpack.add(new Money());
        backpack.add(new Wrench());
    }
    @Override
    public void act() {

    }

    @Override
    public void useBy(Actor actor) {
        // Iteraciu robime na kopii zoznamu
        // Inak by a nemala naraz robit prechadzanie zoznamu a jeho modifikacia
        for (Item item:backpack.getContent()){
            item.setPosition(getX(),getY());
            getWorld().addActor(item);
            backpack.remove(item);
        }


    }
}

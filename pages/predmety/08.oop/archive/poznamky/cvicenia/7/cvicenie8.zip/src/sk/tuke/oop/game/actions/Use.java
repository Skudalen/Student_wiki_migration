package sk.tuke.oop.game.actions;

import sk.tuke.oop.framework.Actor;
import sk.tuke.oop.game.actors.Usable;

public class Use  implements Action {
    private final Actor actor;
    private final Usable actuator;
    public Use(Actor actor,Usable actuator){
        this.actor = actor;
        this.actuator = actuator;
    }

    public void execute() {
        actuator.useBy(actor);
    }
}

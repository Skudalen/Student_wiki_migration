package sk.tuke.oop.game.actors;


import sk.tuke.oop.framework.*;
import sk.tuke.oop.game.actions.Action;
import sk.tuke.oop.game.actions.Move;
import sk.tuke.oop.game.actions.Use;

public class Ripley extends AbstractActor {

    private int health;
    private int ammo;
    public static final String NAME = "Ripley";
    public static final int FULLENERGY = 100;
    public static final int FULLAMMO = 500;

    public Ripley() {
        super(NAME,"sprites/player.png",32,32);
        setHealth(FULLENERGY);
        setAmmo(FULLAMMO);
    }


    @Override
    public void act() {
        Input input = Input.getInstance();
        if(input.isKeyDown(Input.Key.ESCAPE)){
            System.exit(0);
        }

        if (input.isKeyDown(Input.Key.UP)){
            // Krok 4.3
            Action a = new Move(this,2,0,-1);
            a.execute();
        }
        if (input.isKeyDown(Input.Key.DOWN)){
            Action a = new Move(this,2,0,1);
            a.execute();
        }
        if (input.isKeyDown(Input.Key.LEFT)){
            Action a = new Move(this,2,-1,0);
            a.execute();
        }
        if (input.isKeyDown(Input.Key.RIGHT)){
            Action a = new Move(this,2,1,0);
            a.execute();
        }
        if (input.isKeyDown(Input.Key.E)){
            for (Actor actor : getWorld()) {
                if (actor.intersects(this)){
                    // Pozor - tu moze nastat ClassCast Exception
                    // Ako zistime, ci Actor implementuje Usable ???
                    Action a = new Use(this,(Usable) actor);
                    a.execute();
                }
                System.out.println(actor);
            }

        }
    }


    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getAmmo() {
        return ammo;
    }

    public void setAmmo(int ammo) {
        this.ammo = ammo;
    }
}

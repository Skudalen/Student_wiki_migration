package sk.tuke.oop.game.actors;

import sk.tuke.oop.framework.Actor;
import sk.tuke.oop.framework.Message;
import sk.tuke.oop.game.actions.Action;
import sk.tuke.oop.game.actions.Move;

import java.util.Random;

public class Alien extends AbstractActor {

    int round;
    int dx;
    int dy;
    Random rnd;

    public Alien() {
        super("alien","sprites/warrior_alien.png",32,32);
        setPosition(200,100);
        rnd = new Random();
    }

    @Override
    public void act() {
        round += 1;
        if (round % 100 == 99) {
            dx = rnd.nextInt(2) - 1;
            dy = rnd.nextInt(2) - 1;
        }
        Action a = new Move(this,2,dx,dy);
        a.execute();

        for (Actor actor : getWorld()) {
            if (actor.getName() == Ripley.NAME && actor.intersects(this)){
                Ripley r = (Ripley)actor;
                int rh = r.getHealth();
                r.setHealth(rh - 1);
                if (rh - 1  <= 0) {
                    getWorld().showMessage( new Message("Bleee Smrt",250,250));
                    // Koniec Hry
                }
            }
            System.out.println(actor);
        }

        //step(2,dx,dy);

    }

}

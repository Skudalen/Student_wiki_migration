package sk.tuke.oop.game.actors;

import sk.tuke.oop.framework.Actor;

public class Ventilator extends AbstractActor implements Usable {
    private boolean works  = false;
    public Ventilator(){
        super("ventilator","sprites/fan.png",16,16);
        setPosition(250,250);
    }

    @Override
    public void act() {
        if (works)
            this.getAnimation().start();
        else
            this.getAnimation().stop();
    }

    @Override
    public void useBy(Actor actor) {
        works = !works;

    }
}

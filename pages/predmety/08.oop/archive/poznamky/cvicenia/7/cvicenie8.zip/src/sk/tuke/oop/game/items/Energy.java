package sk.tuke.oop.game.items;

import sk.tuke.oop.framework.Actor;
import sk.tuke.oop.framework.Item;
import sk.tuke.oop.game.actors.AbstractActor;
import sk.tuke.oop.game.actors.Ripley;

public class Energy extends AbstractActor implements Item {
    public Energy() {
        super("energy", "sprites/energy.png",16,16);
        setPosition(200,200);
    }

    @Override
    public void act() {
        for (Actor actor : getWorld()) {
            if (actor.getName() == Ripley.NAME && actor.intersects(this)){
                Ripley r = (Ripley)actor;
                int rh = r.getHealth();
                if (rh < Ripley.FULLENERGY){
                    r.setHealth(Ripley.FULLENERGY);
                    getWorld().removeActor(this);
                }

            }
            System.out.println(actor);
        }

    }
}

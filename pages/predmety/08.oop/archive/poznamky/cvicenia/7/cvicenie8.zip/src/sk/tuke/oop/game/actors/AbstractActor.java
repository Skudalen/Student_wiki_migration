package sk.tuke.oop.game.actors;

import sk.tuke.oop.framework.Actor;
import sk.tuke.oop.framework.Animation;
import sk.tuke.oop.framework.World;
import sk.tuke.oop.game.actions.Movable;
import sk.tuke.oop.game.actions.Move;

// Vytvorenie pomocou
// Ripley / Right Click/ Refactor/ Extract / Superclass, zaskrnut vsetko, act() urobit abvstract
// Parameter move moze zostat na Ripleyovej

public abstract class AbstractActor implements Movable {
    protected int x;
    protected int y;
    protected int width;
    protected int height;
    protected String name;
    protected Animation animation;
    private World  world;


    public AbstractActor(String name, String animation_file,int width,int height) {
        y = 100;
        x = 100;
        this.name = name;
        animation = new Animation(animation_file,width,height,100);

    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    @Override
    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public Animation getAnimation() {
        return animation;
    }

    @Override
    public void setAnimation(Animation animation) {
        this.animation = animation;
    }

    @Override
    public abstract void act();

    @Override
    public boolean intersects(Actor actor) {
        // Mozno takto ale nemam cas to ladit
        if (actor.getX() - actor.getWidth() < getX() - getWidth() && actor.getY() - actor.getHeight() < getY() - getHeight())
            return true;
        return false;
    }

    @Override
    public void addedToWorld(World world) {
        this.world = world;
    }

    @Override
    public World getWorld() {
        return world;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String toString(){
        return String.format("%s %d %d",getName(),getX(),getY());
    }

}

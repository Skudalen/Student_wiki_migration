#include <termbox.h>
#include <stdlib.h>
#include <string.h>
#include "world.h"
#include "snake.h"

// Start is called one in the beginning
void start(struct world* world,int argc, char** argv){
    // Allocate memory for the state
    struct state* st = calloc(1,(sizeof(struct state)));
   // Store pointer to the state to the world variable
    world->state = st;
    st->snake = NULL;
    st->sx = 0;
    st->sy = -1;
    int cy = world->height/2;
    int cx = world->width/2;
    st->snake = add_snake(st->snake,cx + 5 ,cy);
    st->snake = add_snake(st->snake,cx + 4,cy);
    st->snake = add_snake(st->snake,cx + 3,cy);
    st->snake = add_snake(st->snake,cx + 2,cy);
    st->snake = add_snake(st->snake,cx + 1,cy);
    st->snake = add_snake(st->snake,cx,cy);

    int h = world->height;
    int w = world->width;

    st->foodx[0] = rand() % w;
    st->foody[0] = rand() % h;
	st->foodx[1] = rand() % w;
    st->foody[1] = rand() % h;
	st->foodx[2] = rand() % w;
    st->foody[2] = rand() % h;
	st->foodx[3] = rand() % w;
    st->foody[3] = rand() % h;
	st->foodx[4] = rand() % w;
    st->foody[4] = rand() % h;
}

// Step is called in a loop once in interval.
// It should modify the state and draw it.
int step(struct world* w,int key){
    // Get state pointer
    struct state* st = w->state;
    enum direction dir = DIR_NONE;
    if (key == TB_KEY_ARROW_LEFT){
        dir = DIR_LEFT;
    }
    else if (key == TB_KEY_ARROW_RIGHT){
        dir = DIR_RIGHT;
    }
    else if (key == TB_KEY_ARROW_UP){
        dir = DIR_UP;
    }
    else if (key == TB_KEY_ARROW_DOWN){
        dir = DIR_DOWN;
    }
    int r = step_state(st,dir,w->width,w->height);
    struct snake* sn = st->snake;
    while (sn != NULL){
        set_character(w,sn->x,sn->y,'x');
        sn = sn->next;
    }
    for (int i = 0 ; i < FOOD_COUNT; i++){
        if (st->foodx[i] >= 0 && st->foody[i] >= 0){
            set_character(w,st->foodx[i],st->foody[i],'*');
        }
    }
    if (r){
        set_message(w,20,20,"Koniec");
    }
    if (key == TB_KEY_ESC){
    	// Non zero means finish the loop and stop the game.
        return 1;
    }

    return 0;
}

// Stop is called after game loop is finished
void stop(struct world* world){
    // Free memory for game state
    struct state* st = world->state;
    free_snake(st->snake);
    free(st);
}

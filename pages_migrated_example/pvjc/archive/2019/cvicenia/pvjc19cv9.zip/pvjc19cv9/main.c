#include "world.h"

int main(int argc, char** argv){
    game(argc,argv);
};

#include "snake.h"
#include <stdlib.h>

struct snake* add_snake(struct snake* snake,int x,int y){
    return NULL;
}

struct snake* remove_snake(struct snake* snake){
   return NULL;
}

void free_snake(struct snake* sn){
}

int step_state(struct state* st,enum direction dir,int width,int height){
    return END_CONTINUE;
}

#ifndef ANKETA_H
#define ANKETA_H
/**
 * Veľkosť buffra pre načítanie reťazcov
 * a maximálna veľkosť mena.
 */
#define BUFSIZE 100
/**
 * Maximálna veľkosť databázy
 */
#define MAXSTUDENTS 50

#include <stdio.h>

/**
 * Jedna položka v databáze
 * Neplatná položka je taká ktorá má počet hlasov 0 alebo meno je prázdny reťazec.
 */
struct student {
    // Meno študenta
    char name[BUFSIZE];
    // Počet získaných hlasov
    int votes;
};
/**
 * Spočítanie platných položiek v databáze.
 * Databáza je ukončená prvou neplatnou položkou alebo koncom poľa.
 * Maximálny počet položiek je MAXSTUDENTS.
 *
 * @return nezáporný počet platných položiek.
 */
int count_students(struct student* students);
/**
 * Vyhľadanie záznamu s daným menom v databáze.
 * Databáza je ukončená prvou neplatnou položkou alebo koncom poľa.
 *
 * @param pole záznamov
 * @param meno na vyhľadanie
 * @return  Index prvého záznamu, ktorý má dané meno. -1 ak sa v poli taký záznam nenachádza.
 */
int search(struct student* students,const char* name);

/**
 * Porovnanie dvoch položiek v databáze podľa počtu hlasov.
 *
 * @return Nula v prápade, že sú položky rovnaké. Kladná hodnota v prípade, že počet hlasov prvej položky je menší ako počet hlasov druhej položky. Záporná hodnota inak.
 */
int compare(const void* s1,const void* s2);


/**
 * Pridanie novej informácie do databázy.
 *
 * Ak sa meno v poli už nachádza, funkcia zvýši počet hlasov pre danú položku.
 * Ak sa meno v databáze nenachádza, funkcia vytvorí nový záznam na prvom voľnom mieste od začiatku.
 *
 * @param pole záznamov
 * @param meno na pridanie
 * @param početnosť na pridanie
 * @return index, kde bola položka pridaná. -1 ak nebolo v poli dosť miesta.
 */
int add_student(struct student* students, const char* name, int votes);

/**
 * Zotriedenie všetkých záznamov podľa počtu hlasov.
 * Databáza je ukončená prvou neplatnou položkou alebo koncom poľa.
 *
 * @param pole na zotriedenie.
 */
void sort_students(struct student* students);

/**
 * Výpis všetkých záznamov na štandardný výstup.
 * Databáza je ukončená prvou neplatnou položkou alebo koncom poľa.
 *
 * @param pole na výpis
 */
void print_students(struct student* students);

/**
 * Načítanie záznamov z otvoreného súboru do poľa.
 *
 * Funkcia načíta maximálne MAXSTUDENTS záznamov, potom skončí.
 * Načítanie skončí aj v prípade načítania neplatnej položky.
 * Jedna položka v textovom súbore je vo formáte:
 *
 * meno
 * početnosť
 *
 * @param otvorený súbor. Otvorený súbor je rovný stdin v prípade načítania zo štandardného vstupu.
 * @param pole kam sa uložia výsledky.
 */
void read_students(FILE* file,struct student* students);

#endif

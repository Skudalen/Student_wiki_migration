#include "anketa.h"
#include <string.h>

int main(){
    struct student students[MAXSTUDENTS];
    memset(students,0,sizeof(struct student)*(MAXSTUDENTS));
    read_students(stdin,students);
    int sz = count_students(students);
    if (sz <= 0){
        // Nenacitalo sa nic
        return 0;
    }
    sort_students(students);
    print_students(students);
    return 0;
}

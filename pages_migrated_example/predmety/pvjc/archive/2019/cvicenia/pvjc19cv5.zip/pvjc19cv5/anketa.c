#include "anketa.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>

int count_students(struct student* students){
    return MAXSTUDENTS;
}

int search(struct student* students,const char* name){
    return -1;
}

int add_student(struct student* students, const char* name, int votes){
    return 0;
}

int compare(const void* s1,const void* s2){
    return 0;
}

void sort_students(struct student* students){
}

void print_students(struct student* students){
}

void read_students(FILE* file,struct student* students){
}


#include "a_station.h"
#include <stdlib.h>
#include <string.h>

struct station* create_station(){
   struct station* station = (struct station*)calloc(1,sizeof(struct station));
   station->tracks = (struct car**)calloc(STATION_SIZE, sizeof(struct car*));
   station->track_count = STATION_SIZE;
   return station;
}

void destroy_station(struct station* station){
}

int select_track(struct station* station, const char* target){
    return 0;
}

void add_target_capacity(struct station* station,const char* target, int capacity){
}

int get_target_capacity(struct station* station,const char* target){
    return 0;
}

int count_targets(struct station* station){
    return 0;
}

int count_capacity(struct station* station){
    return 0;
}

